package com.example.erronkat3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.DocumentSnapshot;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;


public class Erregistroa extends BaseActivity {
    private EditText etNombre, etApellido, etEmail, etContraseña, etFechaDeNacimiento;
    private Spinner spinnerRol; // Spinner para seleccionar el rol
    private FirebaseFirestore db; // Firestore instance

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Inicializar Firestore
        db = FirebaseFirestore.getInstance();

        // Inicializar los elementos de la vista
        etNombre = findViewById(R.id.etIzena);
        etApellido = findViewById(R.id.etAbizena);
        etEmail = findViewById(R.id.etEmail);
        etContraseña = findViewById(R.id.etPasahitza);
        etFechaDeNacimiento = findViewById(R.id.etJaiotzeData);
        spinnerRol = findViewById(R.id.spinnerRol); // Inicializar el Spinner
        Button btnRegister = findViewById(R.id.btnRegister);

        // Configurar el Spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.roles, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerRol.setAdapter(adapter);

        Button btnItzuli = findViewById(R.id.btnItzuli);
        btnItzuli.setOnClickListener(v -> {
            Intent intent = new Intent(Erregistroa.this, LoginActivity.class);
            startActivity(intent);
            finish();
        });

        // Lógica de registro en Firestore
        btnRegister.setOnClickListener(v -> {
            String Nombre = etNombre.getText().toString().trim();
            String Apellido = etApellido.getText().toString().trim();
            String Email = etEmail.getText().toString().trim();
            String contraseña = etContraseña.getText().toString().trim();
            String fechaDeNacimientoStr = etFechaDeNacimiento.getText().toString().trim();
            String rolSeleccionado = spinnerRol.getSelectedItem().toString(); // Obtener valor del Spinner
            boolean Entrenador = rolSeleccionado.equals("Entrenatzailea"); // Convertir a boolean

            // Validar campos vacíos
            if (Nombre.isEmpty() || Apellido.isEmpty() || Email.isEmpty() || contraseña.isEmpty() || fechaDeNacimientoStr.isEmpty()) {
                Toast.makeText(Erregistroa.this, "Mesedez, bete guztiak eremuak", Toast.LENGTH_SHORT).show();
                return;
            }

            // Validar formato de correo electrónico
            if (!Email.contains("@")) {
                Toast.makeText(Erregistroa.this, "E-posta helbide zuzena sartu", Toast.LENGTH_SHORT).show();
                return;
            }

            // Consultar si el correo ya existe en la base de datos
            db.collection("Usuarios")
                    .whereEqualTo("Email", Email)  // Buscamos el correo electrónico
                    .get()
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful() && !task.getResult().isEmpty()) {
                            // Si el correo ya existe, mostramos un mensaje
                            Toast.makeText(Erregistroa.this, "E-posta helbide hau dagoeneko erregistratuta dago", Toast.LENGTH_SHORT).show();
                        } else {
                            // Si el correo no existe, continuamos con la validación de la fecha y el registro
                            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
                            Date fechaDeNacimiento;
                            try {
                                fechaDeNacimiento = sdf.parse(fechaDeNacimientoStr);
                                if (fechaDeNacimiento == null) {
                                    Toast.makeText(Erregistroa.this, "Data formatua ez da egokia", Toast.LENGTH_SHORT).show();
                                    return;
                                }
                            } catch (ParseException e) {
                                Toast.makeText(Erregistroa.this, "Data formatua ez da egokia", Toast.LENGTH_SHORT).show();
                                return;
                            }

                            // Convertir Date a Timestamp
                            Timestamp fechaDeNacimientoTimestamp = new Timestamp(fechaDeNacimiento);

                            // Determinar el nivel según el rol
                            String nivel = Entrenador ? null : "hasiberri"; // Si es entrenador, no asignamos nivel, si no, asignamos "hasiberri"

                            // Obtener el ID más alto y sumarle 1
                            db.collection("Usuarios")
                                    .get()
                                    .addOnCompleteListener(idTask -> {
                                        if (idTask.isSuccessful()) {
                                            long maxId = 0;

                                            // Buscar el ID más alto
                                            for (DocumentSnapshot document : idTask.getResult()) {
                                                try {
                                                    long currentId = Long.parseLong(document.getId()); // El ID es el nombre del documento
                                                    if (currentId > maxId) {
                                                        maxId = currentId; // Si encontramos uno mayor, lo guardamos
                                                    }
                                                } catch (Exception e) {
                                                    // Si el ID no es válido, lo ignoramos
                                                }
                                            }

                                            // Incrementar el ID para el nuevo usuario
                                            long newId = maxId + 1;

                                            // Crear el objeto Usuario
                                            Usuario usuario = new Usuario(Nombre, Apellido, Email, contraseña, fechaDeNacimiento, Entrenador, nivel);

                                            // Guardar el usuario en Firestore con el nuevo ID
                                            Map<String, Object> userMap = usuario.toMap();
                                            db.collection("Usuarios")
                                                    .document(String.valueOf(newId)) // Usamos el nuevo ID como nombre del documento
                                                    .set(userMap)
                                                    .addOnSuccessListener(documentReference -> {
                                                        // Solo crear la subcolección "Historial de Workouts" si el usuario es cliente
                                                        if (!Entrenador) {
                                                            db.collection("Usuarios")
                                                                    .document(String.valueOf(newId))
                                                                    .collection("Historial de Workouts")
                                                                    .document("Referencia")
                                                                    .set(new HashMap<>())
                                                                    .addOnSuccessListener(subCollectionRef -> {
                                                                        Toast.makeText(Erregistroa.this, "Erregistroa y creación de historial completados", Toast.LENGTH_SHORT).show();
                                                                        Intent intent = new Intent(Erregistroa.this, LoginActivity.class);
                                                                        startActivity(intent);
                                                                        finish(); // Finaliza la actividad de registro
                                                                    })
                                                                    .addOnFailureListener(e -> {
                                                                        Toast.makeText(Erregistroa.this, "Error al crear la subcolección: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                                                    });
                                                        } else {
                                                            // Si es entrenador, solo finalizamos el registro
                                                            Toast.makeText(Erregistroa.this, "Erregistroa osatu da", Toast.LENGTH_SHORT).show();
                                                            Intent intent = new Intent(Erregistroa.this, LoginActivity.class);
                                                            startActivity(intent);
                                                            finish(); // Finaliza la actividad de registro
                                                        }
                                                    })
                                                    .addOnFailureListener(e -> {
                                                        Toast.makeText(Erregistroa.this, "Errorea: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                                    });
                                        }
                                    });
                        }
                    });
        });

    }
}
