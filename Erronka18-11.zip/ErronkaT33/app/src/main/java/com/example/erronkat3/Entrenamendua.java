package com.example.erronkat3;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import java.util.ArrayList;
import java.util.Arrays;

public class Entrenamendua extends BaseActivity {

    private ArrayList<String> entrenamientoList; // Lista de entrenamientos
    private FirebaseFirestore db; // Instancia de FirebaseFirestore
    private EditText etFiltroMaila; // EditText para el filtro de nivel
    private Button btnEntrenatzailea; // Botón para los entrenadores
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entrenamenduak);

        // Inicialización de las vistas
        TableLayout tableEntrenamientos = findViewById(R.id.tableEntrenamientos); // Inicializar TableLayout
        etFiltroMaila = findViewById(R.id.etFiltroMaila); // Inicializar EditText para el filtro de nivel
        Button btnIragazkia = findViewById(R.id.btnIragazkia); // Botón para aplicar el filtro
        Button btnItzuli = findViewById(R.id.btnItzuli); // Botón para volver
        Button btnProfila = findViewById(R.id.btnProfila); // Botón para acceder al perfil
        btnEntrenatzailea = findViewById(R.id.btnEntrenatzailea); // Botón visible solo para entrenadores

        // Firebase
        db = FirebaseFirestore.getInstance(); // Obtener instancia de Firestore
        entrenamientoList = new ArrayList<>(); // Inicializar la lista de entrenamientos

        // Obtener el nivel del usuario al iniciar
        FirebaseAuth auth = FirebaseAuth.getInstance();
        String userId = auth.getCurrentUser().getUid();
        db.collection("Usuarios").document(userId).get().addOnSuccessListener(documentSnapshot -> {
            String nivel = documentSnapshot.getString("nivel");

            // Cargar entrenamientos filtrados automáticamente por el nivel del usuario
            cargarEntrenamientos(nivel, tableEntrenamientos);

            // Mostrar el botón de entrenador si el usuario es entrenador
            Boolean esEntrenador = documentSnapshot.getBoolean("Entrenador");
            if (esEntrenador != null && esEntrenador) {
                btnEntrenatzailea.setVisibility(View.VISIBLE); // Mostrar el botón solo si es entrenador
            } else {
                btnEntrenatzailea.setVisibility(View.GONE); // Ocultar el botón si no es entrenador
            }
        });

        // Acción del botón "Iragazkia" (filtrar entrenamientos por nivel)
        btnIragazkia.setOnClickListener(v -> {
            String nivelFiltro = etFiltroMaila.getText().toString().trim();
            cargarEntrenamientos(nivelFiltro, tableEntrenamientos);
        });

        // Acción del botón "Itzuli" (volver a la actividad de login)
        btnItzuli.setOnClickListener(v -> {
            Intent intent = new Intent(Entrenamendua.this, LoginActivity.class);
            startActivity(intent);
            finish(); // Cierra la actividad actual
        });

        // Acción del botón "Profila" (ver el perfil)
        btnProfila.setOnClickListener(v -> {
            Intent intent = new Intent(Entrenamendua.this, Profila.class);
            startActivity(intent);
            finish();
        });
    }

    // Método para cargar entrenamientos filtrados por nivel
    private void cargarEntrenamientos(String nivelFiltro, TableLayout tableEntrenamientos) {
        // Limpiar el TableLayout antes de agregar nuevos elementos
        tableEntrenamientos.removeAllViews();

        // Agregar la fila de encabezado
        tableEntrenamientos.addView(crearHeaderRow());

        // Declarar la variable de la consulta
        Query query = null;

        // Si el usuario es "aurreratua", queremos que vea los entrenamientos de todos los niveles
        if ("aurreratua".equals(nivelFiltro)) {
            query = db.collection("Workouts");
        } else if ("tarteko".equals(nivelFiltro)) {
            // Obtener entrenamientos de nivel "tarteko" y "hasiberri"
            query = db.collection("Workouts").whereIn("nivel", Arrays.asList("tarteko", "hasiberri"));
        } else if ("hasiberri".equals(nivelFiltro)) {
            // Obtener solo entrenamientos de nivel "hasiberri"
            query = db.collection("Workouts").whereEqualTo("nivel", "hasiberri");
        }

        // Obtener los entrenamientos desde Firestore
        if (query != null) {
            query.get()
                    .addOnSuccessListener(queryDocumentSnapshots -> {
                        for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                            String nombre = document.getString("nombre");
                            String nivel = document.getString("nivel");
                            Long numeroEjercicios = document.getLong("numero de ejercicios");

                            // Crear la fila con los datos del entrenamiento
                            TableRow tableRow = new TableRow(Entrenamendua.this);

                            TextView nivelTextView = new TextView(Entrenamendua.this);
                            nivelTextView.setText(nivel);
                            tableRow.addView(nivelTextView);

                            TextView nombreTextView = new TextView(Entrenamendua.this);
                            nombreTextView.setText(nombre);
                            tableRow.addView(nombreTextView);

                            TextView ejerciciosTextView = new TextView(Entrenamendua.this);
                            ejerciciosTextView.setText(String.valueOf(numeroEjercicios));
                            tableRow.addView(ejerciciosTextView);

                            // Agregar la fila a la TableLayout
                            tableEntrenamientos.addView(tableRow);
                        }
                    })
                    .addOnFailureListener(e ->
                            Toast.makeText(Entrenamendua.this, "Error al cargar entrenamientos", Toast.LENGTH_SHORT).show());
        }
    }

    // Método para crear la fila de encabezado
    private TableRow crearHeaderRow() {
        TableRow headerRow = new TableRow(this);

        TextView nivelHeader = new TextView(this);
        nivelHeader.setText("nivel");
        headerRow.addView(nivelHeader);

        TextView nombreHeader = new TextView(this);
        nombreHeader.setText("nombre");
        headerRow.addView(nombreHeader);

        TextView ejerciciosHeader = new TextView(this);
        ejerciciosHeader.setText("ejercicios");
        headerRow.addView(ejerciciosHeader);

        return headerRow;
    }
}
