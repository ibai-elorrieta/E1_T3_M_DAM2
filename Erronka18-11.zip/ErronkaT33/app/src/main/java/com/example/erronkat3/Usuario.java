package com.example.erronkat3;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Usuario {
    private String izena;
    private String abizena;
    private String email;
    private String pasahitza;
    private Date jaiotzeData;
    private boolean entrenatzailea;
    private String nivel;

    // Instancia estática para manejar el usuario actual
    private static Usuario usuarioActual;

    // Constructor completo
    public Usuario(String izena, String abizena, String email, String pasahitza, Date jaiotzeData, boolean entrenatzailea, String nivel) {
        this.izena = izena;
        this.abizena = abizena;
        this.email = email;
        this.pasahitza = pasahitza;
        this.jaiotzeData = jaiotzeData;
        this.entrenatzailea = entrenatzailea;
        this.nivel = nivel;
    }

    // Constructor vacío necesario para Firebase
    public Usuario() {
    }

    // Getters
    public String getIzena() {
        return izena;
    }

    public String getAbizena() {
        return abizena;
    }

    public String getEmail() {
        return email;
    }

    public String getPasahitza() {
        return pasahitza;
    }

    public Date getJaiotzeData() {
        return jaiotzeData;
    }

    public boolean isEntrenatzailea() {
        return entrenatzailea;
    }

    public String getNivel() {
        return nivel;
    }

    public void setIzena(String izena) {
        this.izena = izena;
    }

    public void setAbizena(String abizena) {
        this.abizena = abizena;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPasahitza(String pasahitza) {
        this.pasahitza = pasahitza;
    }

    public void setJaiotzeData(Date jaiotzeData) {
        this.jaiotzeData = jaiotzeData;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }

    public void setEntrenatzailea(boolean entrenatzailea) {
        this.entrenatzailea = entrenatzailea;
    }

    // Método para convertir el objeto Usuario a un Map con los nombres de campos deseados
    public Map<String, Object> toMap() {
        Map<String, Object> userMap = new HashMap<>();
        userMap.put("Apellido", abizena);
        userMap.put("Email", email);
        userMap.put("Entrenador", entrenatzailea);
        userMap.put("Nombre", izena);
        userMap.put("contraseña", pasahitza);
        userMap.put("fecha de nacimiento", jaiotzeData);
        userMap.put("nivel", nivel);
        return userMap;
    }

    // Métodos estáticos para manejar el usuario actual
    public static Usuario getUsuarioActual() {
        if (usuarioActual == null) {
            usuarioActual = new Usuario(); // Se inicializa vacío si no existe
        }
        return usuarioActual;
    }

    public static void setUsuarioActual(Usuario usuario) {
        usuarioActual = usuario;
    }
}

