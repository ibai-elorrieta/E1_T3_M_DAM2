package com.example.erronkat3;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class MainActivity extends Activity {

	// Método onCreate se ejecuta al iniciar la actividad
	// Se carga el layout con la imagen de la app y se espera 3 segundos
	// antes de cambiar a LoginActivity

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);  // Carga el layout con la imagen

        // Usar un Handler para esperar unos segundos y cambiar a LoginActivity
        new Handler().postDelayed(() -> {
            // Crear un intent para cambiar a LoginActivity
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
            // Finalizar MainActivity para evitar volver atrás a ella
            finish();
        }, 3000); // 3000 ms = 3 segundos de espera
    }
}
