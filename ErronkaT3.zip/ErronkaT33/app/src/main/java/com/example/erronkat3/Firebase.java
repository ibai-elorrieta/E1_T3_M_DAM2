package com.example.erronkat3;

import android.app.Application;
import com.google.firebase.FirebaseApp;

public class Firebase extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        // Inicializa Firebase
        FirebaseApp.initializeApp(this);
    }
}