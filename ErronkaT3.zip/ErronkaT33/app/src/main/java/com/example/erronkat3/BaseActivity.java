package com.example.erronkat3;

import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

public class BaseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        SharedPreferences prefs = getSharedPreferences("Settings", MODE_PRIVATE);
        boolean isDarkTheme = prefs.getBoolean("isDarkTheme", false);

        // Aplicar el tema antes de llamar a super.onCreate
        setTheme(isDarkTheme ? R.style.Theme_ErronkaT3_Dark : R.style.Theme_ErronkaT3_Light);

        super.onCreate(savedInstanceState);

        // Configuración de idioma
        String language = prefs.getString("language", "eu");
        setLocale(language);
    }

    private void setLocale(String langCode) {
        Locale locale = new Locale(langCode);
        Locale.setDefault(locale);

        android.content.res.Configuration config = getResources().getConfiguration();
        config.setLocale(locale);
        getResources().updateConfiguration(config, getResources().getDisplayMetrics());
    }
}
