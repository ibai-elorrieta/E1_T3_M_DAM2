package com.example.erronkat3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Objects;

public class Erregistroa extends AppCompatActivity {

    private EditText etIzena, etAbizena, etEmail, etPasahitza, etPasahitzaBerriro, etJaiotzeData;
    private Spinner spinnerRol; // Spinner para seleccionar el rol
    private FirebaseAuth mAuth; // Firebase Auth instance
    private FirebaseFirestore db; // Firestore instance

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Inicializar Firebase Auth y Firestore
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        // Inicializar los elementos de la vista
        etIzena = findViewById(R.id.etIzena);
        etAbizena = findViewById(R.id.etAbizena);
        etEmail = findViewById(R.id.etEmail);
        etPasahitza = findViewById(R.id.etPasahitza);
        etPasahitzaBerriro = findViewById(R.id.etPasahitzaBerriro);
        etJaiotzeData = findViewById(R.id.etJaiotzeData);
        spinnerRol = findViewById(R.id.spinnerRol); // Inicializar el Spinner
        Button btnRegister = findViewById(R.id.btnRegister);

        // Configurar el Spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.roles, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerRol.setAdapter(adapter);

        // Acción del botón de registro
        btnRegister.setOnClickListener(v -> {
            String izena = etIzena.getText().toString();
            String abizena = etAbizena.getText().toString();
            String email = etEmail.getText().toString();
            String pasahitza = etPasahitza.getText().toString();
            String pasahitzaBerriro = etPasahitzaBerriro.getText().toString();
            String jaiotzeDataStr = etJaiotzeData.getText().toString();
            String rolSeleccionado = spinnerRol.getSelectedItem().toString(); // Obtener valor del Spinner
            boolean entrenatzailea = rolSeleccionado.equals("Entrenatzailea"); // Convertir a boolean

            // Validar campos
            if (izena.isEmpty() || abizena.isEmpty() || email.isEmpty() || pasahitza.isEmpty() ||
                    pasahitzaBerriro.isEmpty() || jaiotzeDataStr.isEmpty()) {
                Toast.makeText(Erregistroa.this, "Bete guztiak", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!pasahitza.equals(pasahitzaBerriro)) {
                Toast.makeText(Erregistroa.this, "Pasahitzak ez dira berdinak", Toast.LENGTH_SHORT).show();
                return;
            }

            // Convertir la fecha de nacimiento a Date
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
            Date jaiotzeData;
            try {
                jaiotzeData = sdf.parse(jaiotzeDataStr);
                if (jaiotzeData == null) {
                    Toast.makeText(Erregistroa.this, "Data formatua ez da egokia", Toast.LENGTH_SHORT).show();
                    return;
                }
            } catch (ParseException e) {
                Toast.makeText(Erregistroa.this, "Data formatua ez da egokia", Toast.LENGTH_SHORT).show();
                return;
            }

            // Lógica de registro en Firebase
            mAuth.createUserWithEmailAndPassword(email, pasahitza)
                    .addOnCompleteListener(this, task -> {
                        if (task.isSuccessful()) {
                            // Registro exitoso
                            String userId = Objects.requireNonNull(mAuth.getCurrentUser()).getUid();

                            // Crear un objeto Usuario con los datos del usuario
                            // Agregar el nivel aquí; usa un valor predeterminado si no es un entrenador
                            String nivel = entrenatzailea ? null : "hasiberri"; // O cualquier nivel que desees definir
                            Usuario usuario = new Usuario(izena, abizena, email, jaiotzeData, entrenatzailea, nivel);

                            // Guardar datos adicionales en Firestore
                            db.collection("usuarios").document(userId)
                                    .set(usuario)
                                    .addOnSuccessListener(aVoid -> {
                                        Toast.makeText(Erregistroa.this, "Erregistroa osatu da", Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(Erregistroa.this, LoginActivity.class);
                                        startActivity(intent);
                                        finish(); // Finaliza la actividad de registro
                                    })
                                    .addOnFailureListener(e -> Toast.makeText(Erregistroa.this, "Errorea: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                        } else {
                            // Si el registro falla, muestra un mensaje al usuario
                            Toast.makeText(Erregistroa.this, "Errorea: " + Objects.requireNonNull(task.getException()).getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
        });
    }
}

