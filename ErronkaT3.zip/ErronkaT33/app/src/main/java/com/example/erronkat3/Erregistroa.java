package com.example.erronkat3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.FirebaseFirestore;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Objects;

public class Erregistroa extends BaseActivity {
    private EditText etNombre, etApellido, etEmail, etContraseña, etFechaDeNacimiento;
    private Spinner spinnerRol; // Spinner para seleccionar el rol
    private FirebaseFirestore db; // Firestore instance

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Inicializar Firestore
        db = FirebaseFirestore.getInstance();

        // Inicializar los elementos de la vista
        etNombre = findViewById(R.id.etIzena);
        etApellido = findViewById(R.id.etAbizena);
        etEmail = findViewById(R.id.etEmail);
        etContraseña = findViewById(R.id.etPasahitza);
        etFechaDeNacimiento = findViewById(R.id.etJaiotzeData);
        spinnerRol = findViewById(R.id.spinnerRol); // Inicializar el Spinner
        Button btnRegister = findViewById(R.id.btnRegister);

        // Configurar el Spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.roles, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerRol.setAdapter(adapter);

        // Acción del botón de registro
        btnRegister.setOnClickListener(v -> {
            String Nombre = etNombre.getText().toString().trim();
            String Apellido = etApellido.getText().toString().trim();
            String Email = etEmail.getText().toString().trim();
            String contraseña = etContraseña.getText().toString().trim();
            String fechaDeNacimientoStr = etFechaDeNacimiento.getText().toString().trim();
            String rolSeleccionado = spinnerRol.getSelectedItem().toString(); // Obtener valor del Spinner
            boolean Entrenador = rolSeleccionado.equals("Entrenatzailea"); // Convertir a boolean

            // Validar campos vacíos
            if (Nombre.isEmpty() || Apellido.isEmpty() || Email.isEmpty() || contraseña.isEmpty() || fechaDeNacimientoStr.isEmpty()) {
                Toast.makeText(Erregistroa.this, "Mesedez, bete guztiak eremuak", Toast.LENGTH_SHORT).show();
                return;
            }

            // Validar formato de correo electrónico
            if (!Email.contains("@")) {
                Toast.makeText(Erregistroa.this, "E-posta helbide zuzena sartu", Toast.LENGTH_SHORT).show();
                return;
            }

            // Convertir la fecha de nacimiento a Date
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
            Date fechaDeNacimiento;
            try {
                fechaDeNacimiento = sdf.parse(fechaDeNacimientoStr);
                if (fechaDeNacimiento == null) {
                    Toast.makeText(Erregistroa.this, "Data formatua ez da egokia", Toast.LENGTH_SHORT).show();
                    return;
                }
            } catch (ParseException e) {
                Toast.makeText(Erregistroa.this, "Data formatua ez da egokia", Toast.LENGTH_SHORT).show();
                return;
            }

            // Convertir Date a Timestamp
            Timestamp fechaDeNacimientoTimestamp = new Timestamp(fechaDeNacimiento);

            // Lógica de registro en Firestore
            db.collection("Usuarios")
                    .get()
                    .addOnCompleteListener(queryTask -> {
                        if (queryTask.isSuccessful()) {
                            // Determinar el nivel según el rol
                            String nivel = Entrenador ? null : "hasiberri"; // Si es entrenador, no asignamos nivel, si no, asignamos "hasiberri"

                            // Crear un objeto Usuario con los datos del usuario
                            Usuario usuario = new Usuario(Nombre, Apellido, Email, contraseña, fechaDeNacimientoTimestamp, Entrenador, nivel);

                            // Guardar datos en Firestore con un ID automático generado por Firestore
                            db.collection("Usuarios")
                                    .add(usuario) // Firestore genera el ID automáticamente
                                    .addOnSuccessListener(documentReference -> {
                                        // Solo crear la subcolección "Historial de Workouts" si el usuario es cliente (Entrenador == false)
                                        if (!Entrenador) {
                                            db.collection("Usuarios")
                                                    .document(documentReference.getId())
                                                    .collection("Historial de Workouts")
                                                    .document("Referencia")
                                                    .set(new HashMap<String, Object>() {{
                                                        put("Historial", "EL DOCUMENTO NO SE DEBE USAR, ES UNA REFERENCIA PARA CREAR EL HISTORIAL");
                                                    }})
                                                    .addOnSuccessListener(subCollectionRef -> {
                                                        Toast.makeText(Erregistroa.this, "Erregistroa y creación de historial completados", Toast.LENGTH_SHORT).show();
                                                        Intent intent = new Intent(Erregistroa.this, LoginActivity.class);
                                                        startActivity(intent);
                                                        finish(); // Finaliza la actividad de registro
                                                    })
                                                    .addOnFailureListener(e ->
                                                            Toast.makeText(Erregistroa.this, "Error al crear la subcolección: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                                                    );
                                        } else {
                                            // Si es entrenador, solo finalizamos el registro sin crear la subcolección
                                            Toast.makeText(Erregistroa.this, "Erregistroa osatu da", Toast.LENGTH_SHORT).show();
                                            Intent intent = new Intent(Erregistroa.this, LoginActivity.class);
                                            startActivity(intent);
                                            finish(); // Finaliza la actividad de registro
                                        }
                                    })
                                    .addOnFailureListener(e -> Toast.makeText(Erregistroa.this, "Errorea: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                        } else {
                            // Si no se pudo obtener la colección de usuarios, manejar el error
                            Toast.makeText(Erregistroa.this, "Errorea al consultar la colección de usuarios: " + Objects.requireNonNull(queryTask.getException()).getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
        });
    }
}

