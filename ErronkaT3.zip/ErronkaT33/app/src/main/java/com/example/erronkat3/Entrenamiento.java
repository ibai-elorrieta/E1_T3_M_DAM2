package com.example.erronkat3;

public class Entrenamiento {
    private String nombre;
    private String nivel;
    private int numeroDeEjercicios;
    private String url;

    public Entrenamiento() {
        // Constructor vacío para Firebase
    }

    public Entrenamiento(String nombre, String nivel, int numeroDeEjercicios, String url) {
        this.nombre = nombre;
        this.nivel = nivel;
        this.numeroDeEjercicios = numeroDeEjercicios;
        this.url = url;
    }

    public String getNombre() {
        return nombre;
    }

    public String getNivel() {
        return nivel;
    }

    public int getNumeroDeEjercicios() {
        return numeroDeEjercicios;
    }

    public String getUrl() {
        return url;
    }
}

