package com.example.erronkat3;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

public class Historiala extends BaseActivity {

    // Firebase Firestore
    private final FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historiala);

        // Referencias a la UI
        Button btnItzuli = findViewById(R.id.btnItzuli);
        TableLayout tableHistorial = findViewById(R.id.tableHistorial);

        // Recupera el usuario actual desde la clase Usuario
        Usuario usuarioActual = Usuario.getUsuarioActual();
        String userEmail = usuarioActual.getEmail(); // Correo del usuario actual

        // Accede a la subcolección de historial de workouts del usuario
        db.collection("Usuarios")
                .document(userEmail) // Correo del usuario
                .collection("Historial de Workouts")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        // Verificar que la consulta devolvió datos
                        if (task.getResult().isEmpty()) {
                            Log.d("Historiala", "No se encontraron datos en el historial");
                        } else {
                            Log.d("Historiala", "Datos recuperados correctamente");

                            for (QueryDocumentSnapshot document : task.getResult()) {
                                // Recupera los datos del documento
                                Integer nSeries = document.getLong("N de series completados") != null ? document.getLong("N de series completados").intValue() : 0;
                                String fecha = document.getDate("fecha") != null ? document.getDate("fecha").toString() : "Fecha no disponible";
                                Integer idWorkout = document.getLong("idWorkout") != null ? document.getLong("idWorkout").intValue() : 0;
                                Integer tiempoTot = document.getLong("tiempotot") != null ? document.getLong("tiempotot").intValue() : 0;

                                Log.d("Historiala", "Datos del documento: " + nSeries + ", " + fecha + ", " + idWorkout + ", " + tiempoTot);

                                // Crear y añadir filas en la tabla
                                TableRow row = new TableRow(Historiala.this);

                                TextView tvNSeries = new TextView(Historiala.this);
                                tvNSeries.setText(String.valueOf(nSeries));
                                tvNSeries.setPadding(8, 8, 8, 8);

                                TextView tvFecha = new TextView(Historiala.this);
                                tvFecha.setText(fecha);
                                tvFecha.setPadding(8, 8, 8, 8);

                                TextView tvIdWorkout = new TextView(Historiala.this);
                                tvIdWorkout.setText(String.valueOf(idWorkout));
                                tvIdWorkout.setPadding(8, 8, 8, 8);

                                TextView tvTiempoTot = new TextView(Historiala.this);
                                tvTiempoTot.setText(String.valueOf(tiempoTot));
                                tvTiempoTot.setPadding(8, 8, 8, 8);

                                // Añadir las celdas a la fila
                                row.addView(tvNSeries);
                                row.addView(tvFecha);
                                row.addView(tvIdWorkout);
                                row.addView(tvTiempoTot);

                                // Añadir la fila a la tabla
                                tableHistorial.addView(row);
                            }
                        }
                    } else {
                        Log.e("Historiala", "Error al obtener los datos: ", task.getException());
                    }
                });

        // Configurar el botón "Itzuli" para volver a la pantalla anterior
        btnItzuli.setOnClickListener(v -> {
            Intent intent = new Intent(Historiala.this, Entrenamendua.class);
            startActivity(intent);
            finish();
        });
    }
}

