package com.example.erronkat3;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import java.util.Arrays;

public class Entrenamendua extends BaseActivity {

    private FirebaseFirestore db;
    private TableLayout tableEntrenamientos;
    private EditText etFiltroMaila;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entrenamenduak);

        // Inicialización de las vistas
        tableEntrenamientos = findViewById(R.id.tableEntrenamientos);
        etFiltroMaila = findViewById(R.id.etFiltroMaila);
        Button btnIragazkia = findViewById(R.id.btnIragazkia);
        Button btnProfila = findViewById(R.id.btnProfila);
        Button btnItzuli = findViewById(R.id.btnItzuli);
        Button btnHistoriala = findViewById(R.id.btnWorkoutHistoriala);

        // Firebase
        db = FirebaseFirestore.getInstance();

        // Obtener nivel del usuario almacenado en el objeto Usuario
        String nivelUsuario = Usuario.getUsuarioActual().getNivel();

        // Cargar entrenamientos filtrados automáticamente por el nivel del usuario
        cargarEntrenamientos(nivelUsuario);

        // Acción del botón "Iragazkia" (filtrar entrenamientos por nivel)
        btnIragazkia.setOnClickListener(v -> {
            String nivelFiltro = etFiltroMaila.getText().toString().trim();

            // Si el filtro está vacío, recargar todos los entrenamientos según el nivel del usuario
            if (nivelFiltro.isEmpty()) {
                cargarEntrenamientos(nivelUsuario);
            } else {
                cargarEntrenamientosConFiltro(nivelUsuario, nivelFiltro);
            }
        });


        btnHistoriala.setOnClickListener(v -> {
            // Crear un Intent para cambiar a la actividad Historiala
            Intent intent = new Intent(Entrenamendua.this, Historiala.class);
            startActivity(intent);
        });

        // Acción del botón "Profila"
        btnProfila.setOnClickListener(v -> {
            Intent intent = new Intent(Entrenamendua.this, Profila.class);
            startActivity(intent);
            finish();
        });

        // Acción del botón "Itzuli"
        btnItzuli.setOnClickListener(v -> {
            Intent intent = new Intent(Entrenamendua.this, LoginActivity.class);
            startActivity(intent);
            finish(); // Cierra la actividad actual
        });
    }

    // Método para cargar entrenamientos según el nivel del usuario al iniciar
    private void cargarEntrenamientos(String nivelUsuario) {
        // Limpiar el TableLayout antes de agregar nuevos elementos
        tableEntrenamientos.removeAllViews();
        tableEntrenamientos.addView(crearHeaderRow());

        // Crear la consulta inicial basada en el nivel del usuario
        Query query = db.collection("Workouts");

        // Ajustar la consulta según el nivel del usuario
        if ("hasiberri".equals(nivelUsuario)) {
            query = query.whereEqualTo("nivel", "hasiberri");
        } else if ("tarteko".equals(nivelUsuario)) {
            query = query.whereIn("nivel", Arrays.asList("tarteko", "hasiberri"));
        } else if ("aurreratua".equals(nivelUsuario)) {
            // "aurreratua" ve todos los niveles
        }

        // Ejecutar la consulta y cargar los entrenamientos
        ejecutarConsultaEntrenamientos(query);
    }

    // Método para cargar entrenamientos con el filtro proporcionado por el usuario
    private void cargarEntrenamientosConFiltro(String nivelUsuario, String nivelFiltro) {
        // Limpiar el TableLayout antes de agregar nuevos elementos
        tableEntrenamientos.removeAllViews();
        tableEntrenamientos.addView(crearHeaderRow());

        // Validar si el filtro excede el nivel del usuario
        if (!esNivelValido(nivelUsuario, nivelFiltro)) {
            Toast.makeText(this, "No puedes ver entrenamientos de nivel superior al tuyo", Toast.LENGTH_SHORT).show();
            return;
        }

        // Crear consulta a Firestore con el filtro proporcionado
        Query query = db.collection("Workouts").whereEqualTo("nivel", nivelFiltro);

        // Ejecutar la consulta y cargar los entrenamientos
        ejecutarConsultaEntrenamientos(query);
    }

    // Método auxiliar para validar si el filtro es válido según el nivel del usuario
    private boolean esNivelValido(String nivelUsuario, String nivelFiltro) {
        switch (nivelUsuario) {
            case "hasiberri":
                return "hasiberri".equals(nivelFiltro);
            case "tarteko":
                return Arrays.asList("tarteko", "hasiberri").contains(nivelFiltro);
            case "aurreratua":
                return Arrays.asList("aurreratua", "tarteko", "hasiberri").contains(nivelFiltro);
            default:
                return false;
        }
    }

    private void ejecutarConsultaEntrenamientos(Query query) {
        query.get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (queryDocumentSnapshots.isEmpty()) {
                        Toast.makeText(Entrenamendua.this, "No hay entrenamientos disponibles", Toast.LENGTH_SHORT).show();
                    } else {
                        for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                            String nombre = document.getString("nombre");
                            String nivel = document.getString("nivel");
                            Long numeroEjercicios = document.getLong("numero de ejercicios");
                            String videoUrl = document.getString("url");  // Obtener la URL del video

                            // Crear la fila con los datos del entrenamiento
                            TableRow tableRow = new TableRow(Entrenamendua.this);

                            // Añadir las vistas de texto
                            TextView nivelTextView = crearTextView(nivel);
                            TextView nombreTextView = crearTextView(nombre);
                            TextView ejerciciosTextView = crearTextView(String.valueOf(numeroEjercicios));

                            // Añadir un listener para abrir el video cuando se haga clic en la fila
                            tableRow.setOnClickListener(v -> {
                                TextView videoLabel = findViewById(R.id.tvVideoLabel);
                                VideoView videoView = findViewById(R.id.videoView);

                                try {
                                    // Validar la URL del video
                                    if (videoUrl == null || videoUrl.isEmpty()) {
                                        throw new IllegalArgumentException("La URL del video está vacía o no es válida.");
                                    }

                                    // Hacer visible el video y el label
                                    videoLabel.setVisibility(View.VISIBLE);
                                    videoView.setVisibility(View.VISIBLE);

                                    // Configurar el VideoView con la URL
                                    Uri videoUri = Uri.parse(videoUrl);
                                    videoView.setVideoURI(videoUri);

                                    // Iniciar la reproducción del video
                                    videoView.start();

                                    videoView.setOnCompletionListener(mp -> {
                                        // Ocultar el VideoView y la etiqueta cuando termine el video
                                        videoView.setVisibility(View.GONE);
                                        videoLabel.setVisibility(View.GONE);
                                    });

                                    videoView.setOnErrorListener((mp, what, extra) -> {
                                        // Manejar errores de reproducción
                                        mostrarMensajeError("Error al reproducir el video.");
                                        videoView.setVisibility(View.GONE);
                                        videoLabel.setVisibility(View.GONE);
                                        return true; // Indica que el error ha sido manejado
                                    });

                                } catch (IllegalArgumentException e) {
                                    mostrarMensajeError("La URL del video no es válida.");
                                } catch (Exception e) {
                                    mostrarMensajeError("Ocurrió un error inesperado: " + e.getMessage());
                                }
                            });

                            tableRow.addView(nivelTextView);
                            tableRow.addView(nombreTextView);
                            tableRow.addView(ejerciciosTextView);

                            // Agregar la fila a la TableLayout
                            tableEntrenamientos.addView(tableRow);
                        }
                    }
                })
                .addOnFailureListener(e -> Toast.makeText(Entrenamendua.this, "Error al cargar entrenamientos", Toast.LENGTH_SHORT).show());
    }

    // Método para mostrar mensajes de error
    private void mostrarMensajeError(String mensaje) {
        Toast.makeText(this, mensaje, Toast.LENGTH_LONG).show();
    }

    // Método para crear la fila de encabezado
    private TableRow crearHeaderRow() {
        TableRow headerRow = new TableRow(this);

        TextView nivelHeader = new TextView(this);
        nivelHeader.setText(getString(R.string.nivel));
        headerRow.addView(nivelHeader);

        TextView nombreHeader = new TextView(this);
        nombreHeader.setText(getString(R.string.nombre));
        headerRow.addView(nombreHeader);

        TextView ejerciciosHeader = new TextView(this);
        ejerciciosHeader.setText(getString(R.string.ejercicios));
        headerRow.addView(ejerciciosHeader);

        return headerRow;
    }


    // Método auxiliar para crear un TextView con estilo
    private TextView crearTextView(String texto) {
        TextView textView = new TextView(Entrenamendua.this);
        textView.setText(texto);
        textView.setPadding(16, 8, 16, 8);
        textView.setTextSize(16);
        return textView;
    }
}
