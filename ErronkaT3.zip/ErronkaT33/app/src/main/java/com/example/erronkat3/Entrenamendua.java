package com.example.erronkat3;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import java.util.ArrayList;

public class Entrenamendua extends AppCompatActivity {

    private ListView listViewHistorikoak; // ListView para mostrar los entrenamientos
    private ArrayList<String> entrenamientoList; // Lista de entrenamientos
    private ArrayAdapter<String> entrenamientoAdapter; // Adaptador para el ListView
    private FirebaseFirestore db; // Instancia de FirebaseFirestore
    private EditText etFiltroMaila; // EditText para el filtro de nivel
    private Button btnEntrenatzailea; // Botón para los entrenadores

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entrenamenduak);

        // Inicialización de las vistas
        listViewHistorikoak = findViewById(R.id.listViewHistorikoak); // Inicializar ListView
        etFiltroMaila = findViewById(R.id.etFiltroMaila); // Inicializar EditText para el filtro de nivel
        Button btnIragazkia = findViewById(R.id.btnIragazkia); // Botón para aplicar el filtro
        Button btnItzuli = findViewById(R.id.btnItzuli); // Botón para volver
        Button btnProfila = findViewById(R.id.btnProfila); // Botón para acceder al perfil
        btnEntrenatzailea = findViewById(R.id.btnEntrenatzailea); // Botón visible solo para entrenadores

        // Firebase
        db = FirebaseFirestore.getInstance(); // Obtener instancia de Firestore
        entrenamientoList = new ArrayList<>(); // Inicializar la lista de entrenamientos
        entrenamientoAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, entrenamientoList); // Inicializar el adaptador
        listViewHistorikoak.setAdapter(entrenamientoAdapter); // Configurar el adaptador en el ListView

        // Obtener el nivel del usuario al iniciar
        FirebaseAuth auth = FirebaseAuth.getInstance();
        String userId = auth.getCurrentUser().getUid();
        db.collection("Usuarios").document(userId).get().addOnSuccessListener(documentSnapshot -> {
            String nivel = documentSnapshot.getString("nivel");

            // Cargar entrenamientos filtrados automáticamente por el nivel del usuario
            cargarEntrenamientos(nivel);

            // Mostrar el botón de entrenador si el usuario es entrenador
            Boolean esEntrenador = documentSnapshot.getBoolean("Entrenador");
            if (esEntrenador != null && esEntrenador) {
                btnEntrenatzailea.setVisibility(View.VISIBLE); // Mostrar el botón solo si es entrenador
            } else {
                btnEntrenatzailea.setVisibility(View.GONE); // Ocultar el botón si no es entrenador
            }
        });

        // Acción del botón "Iragazkia" (filtrar entrenamientos por nivel)
        btnIragazkia.setOnClickListener(v -> {
            String nivelFiltro = etFiltroMaila.getText().toString().trim();
            cargarEntrenamientos(nivelFiltro);
        });

        // Acción del botón "Itzuli" (volver a la actividad de login)
        btnItzuli.setOnClickListener(v -> {
            Intent intent = new Intent(Entrenamendua.this, LoginActivity.class);
            startActivity(intent);
            finish(); // Cierra la actividad actual
        });

        // Acción del botón "Profila" (ver el perfil)
        btnProfila.setOnClickListener(v -> {
            Intent intent = new Intent(Entrenamendua.this, Profila.class);
            startActivity(intent);
            finish();
        });
    }

    // Método para cargar entrenamientos filtrados por nivel
    private void cargarEntrenamientos(String nivelFiltro) {
        // Verifica si el filtro es vacío y asigna un valor por defecto si es necesario
        if (nivelFiltro == null || nivelFiltro.isEmpty()) {
            nivelFiltro = ""; // Si está vacío, no filtra por nivel
        }

        CollectionReference workoutsRef = db.collection("Workouts");
        Query query;

        if (nivelFiltro.isEmpty()) {
            query = workoutsRef; // Si no hay filtro, mostrar todos los entrenamientos
        } else {
            query = workoutsRef.whereEqualTo("nivel", nivelFiltro); // Filtrar por nivel
        }

        // Obtener los entrenamientos desde Firestore
        query.get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    entrenamientoList.clear(); // Limpiar la lista actual de entrenamientos
                    for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                        Entrenamiento entrenamiento = document.toObject(Entrenamiento.class);
                        entrenamientoList.add(entrenamiento.toString()); // Agregar los entrenamientos a la lista
                    }
                    entrenamientoAdapter.notifyDataSetChanged(); // Notificar al adaptador de la actualización
                })
                .addOnFailureListener(e ->
                        Toast.makeText(Entrenamendua.this, "Error al cargar entrenamientos", Toast.LENGTH_SHORT).show());
    }
}
