package com.example.erronkat3;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.DocumentSnapshot;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class LoginActivity extends BaseActivity {

    private EditText etErabiltzailea, etPasahitza;
    private CheckBox chkRememberMe;
    private SharedPreferences prefs;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Inicializar Firebase y Firestore
        FirebaseApp.initializeApp(this);
        db = FirebaseFirestore.getInstance();

        // Inicializar los elementos de la vista
        etErabiltzailea = findViewById(R.id.etErabiltzailea);
        etPasahitza = findViewById(R.id.etPasahitza);
        chkRememberMe = findViewById(R.id.chkRememberMe);
        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnErregistratu = findViewById(R.id.btnErregistratu);

        // Inicializar preferencias compartidas
        prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        cargarPreferencias();

        // Acción del botón Login
        btnLogin.setOnClickListener(v -> {
            String erabiltzailea = etErabiltzailea.getText().toString().trim();
            String pasahitza = etPasahitza.getText().toString().trim();

            if (erabiltzailea.isEmpty() || pasahitza.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Bete erabiltzailea eta gakoa", Toast.LENGTH_SHORT).show();
            } else if (!Patterns.EMAIL_ADDRESS.matcher(erabiltzailea).matches()) {
                Toast.makeText(this, "Sartu baliozko posta elektronikoa", Toast.LENGTH_SHORT).show();
            } else {
                // Autenticación personalizada en Firestore
                iniciarSesion(erabiltzailea, pasahitza);
            }
        });

        // Acción del botón Erregistratu
        btnErregistratu.setOnClickListener(v -> {
            // Navegar a la pantalla de registro (ErregistroActivity)
            Intent intent = new Intent(LoginActivity.this, Erregistroa.class);
            startActivity(intent);
        });
    }

    private void iniciarSesion(String email, String password) {
        db.collection("Usuarios")
                .whereEqualTo("Email", email)
                .whereEqualTo("contraseña", password)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        // Comprobamos si hay documentos en los resultados
                        if (!task.getResult().isEmpty()) {
                            DocumentSnapshot document = task.getResult().getDocuments().get(0); // Obtener el primer documento
                            if (document.exists()) {
                                // El documento existe, obtenemos los campos
                                String nombre = document.getString("Nombre");
                                String apellido = document.getString("Apellido");
                                String emailUsuario = document.getString("Email");
                                String contrasena = document.getString("contraseña");
                                String nivel = document.getString("nivel");

                                // Obtener la fecha de nacimiento (suponiendo que es un Timestamp)
                                Timestamp timestampFechaNacimiento = document.getTimestamp("fecha de nacimiento");
                                String fechaNacimiento = "";
                                if (timestampFechaNacimiento != null) {
                                    Date fecha = timestampFechaNacimiento.toDate(); // Convertimos el Timestamp a un objeto Date
                                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()); // Formato deseado
                                    fechaNacimiento = sdf.format(fecha); // Convertimos la fecha a una cadena
                                }

                                // Mostrar un mensaje de éxito
                                Toast.makeText(LoginActivity.this, "Saioa hasi da", Toast.LENGTH_SHORT).show();

                                // Guardamos la información en SharedPreferences
                                gestionarPreferencias(emailUsuario, contrasena, nombre, apellido, fechaNacimiento, nivel);

                                // Redirigir a la pantalla principal
                                Intent intent = new Intent(LoginActivity.this, Entrenamendua.class);
                                startActivity(intent);
                                finish();
                            }
                        } else {
                            // Autenticación fallida
                            Toast.makeText(LoginActivity.this, "Errorea: erabiltzailea edo pasahitza okerra", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        // Error en la consulta
                        Toast.makeText(LoginActivity.this, "Errorea egiaztatzean: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }




    private void cargarPreferencias() {
        // Recuperamos siempre el nombre, apellido, fecha de nacimiento y nivel
        String nombre = prefs.getString("nombre", "");
        String apellido = prefs.getString("apellido", "");
        String fechaNacimiento = prefs.getString("fechaNacimiento", "");
        String nivel = prefs.getString("nivel", "");

        // Mostramos los datos (esto es un ejemplo, podrías mostrarlos en TextViews o utilizarlos como desees)
        Log.d("LoginActivity", "Nombre: " + nombre + ", Apellido: " + apellido + ", Fecha de nacimiento: " + fechaNacimiento + ", Nivel: " + nivel);

        // Recuperamos email y contraseña solo si "Remember me" está activado
        String savedEmail = prefs.getString("email", "");
        String savedPassword = prefs.getString("password", "");
        etErabiltzailea.setText(savedEmail);
        etPasahitza.setText(savedPassword);
        chkRememberMe.setChecked(prefs.getBoolean("rememberMe", false));
    }

    private void gestionarPreferencias(String email, String contrasena, String nombre, String apellido, String fechaNacimiento, String nivel) {
        SharedPreferences.Editor editor = prefs.edit();
        // Siempre guardamos el nombre, apellido, fecha de nacimiento y nivel
        editor.putString("nombre", nombre);
        editor.putString("apellido", apellido);
        editor.putString("fechaNacimiento", fechaNacimiento);
        editor.putString("nivel", nivel);

        // Si se selecciona "Remember me", también guardamos el email y la contraseña
        if (chkRememberMe.isChecked()) {
            editor.putString("email", email);
            editor.putString("password", contrasena);
            editor.putBoolean("rememberMe", true);
        } else {
            // Si no se selecciona "Remember me", eliminamos email y contraseña
            editor.remove("email");
            editor.remove("password");
            editor.putBoolean("rememberMe", false);
        }
        editor.apply();
    }
}
