package com.example.erronkat3;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.DocumentSnapshot;

import java.util.Objects;

public class LoginActivity extends BaseActivity {

    private EditText etErabiltzailea, etPasahitza;
    private CheckBox chkRememberMe;
    private SharedPreferences prefs;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Inicializar Firebase y Firestore
        FirebaseApp.initializeApp(this);
        db = FirebaseFirestore.getInstance();

        // Inicializar los elementos de la vista
        etErabiltzailea = findViewById(R.id.etErabiltzailea);
        etPasahitza = findViewById(R.id.etPasahitza);
        chkRememberMe = findViewById(R.id.chkRememberMe);
        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnErregistratu = findViewById(R.id.btnErregistratu);

        // Inicializar preferencias compartidas
        prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        cargarPreferencias();

        // Acción del botón Login
        btnLogin.setOnClickListener(v -> {
            String erabiltzailea = etErabiltzailea.getText().toString().trim();
            String pasahitza = etPasahitza.getText().toString().trim();

            if (erabiltzailea.isEmpty() || pasahitza.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Bete erabiltzailea eta gakoa", Toast.LENGTH_SHORT).show();
            } else if (!Patterns.EMAIL_ADDRESS.matcher(erabiltzailea).matches()) {
                Toast.makeText(this, "Sartu baliozko posta elektronikoa", Toast.LENGTH_SHORT).show();
            } else {
                // Autenticación personalizada en Firestore
                iniciarSesion(erabiltzailea, pasahitza);
            }
        });

        // Acción del botón Erregistratu
        btnErregistratu.setOnClickListener(v -> {
            // Navegar a la pantalla de registro (ErregistroActivity)
            Intent intent = new Intent(LoginActivity.this, Erregistroa.class);
            startActivity(intent);
            finish();
        });
    }

    private void iniciarSesion(String email, String password) {
        // Primero, buscamos si el email existe
        db.collection("Usuarios")
                .whereEqualTo("Email", email)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        if (!task.getResult().isEmpty()) {
                            // Si el email existe, obtenemos el documento y verificamos la contraseña
                            DocumentSnapshot document = task.getResult().getDocuments().get(0);
                            String storedPassword = document.getString("contraseña");

                            if (storedPassword != null && storedPassword.equals(password)) {
                                // Contraseña correcta
                                // Crear usuario desde el documento
                                Usuario usuario = obtenerUsuario(document, password);

                                // Configurar el usuario actual
                                Usuario.setUsuarioActual(usuario);

                                // Guardar email/contraseña si corresponde al "Remember me"
                                gestionarPreferencias(email, password);

                                // Navegar a la siguiente actividad
                                Toast.makeText(LoginActivity.this, "Saioa hasi da", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(LoginActivity.this, Entrenamendua.class);
                                startActivity(intent);
                                finish();
                            } else {
                                // Contraseña incorrecta
                                Toast.makeText(LoginActivity.this, "Errorea: pasahitza okerra", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            // Email no encontrado
                            Toast.makeText(LoginActivity.this, "Errorea: erabiltzailea ez da existitzen", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        // Error con la base de datos
                        Log.e("LoginActivity", "Errorea: " + Objects.requireNonNull(task.getException()).getMessage());
                        Toast.makeText(LoginActivity.this, "Errorea zerbitzuarekin", Toast.LENGTH_SHORT).show();
                    }
                });
    }
    private Usuario obtenerUsuario(DocumentSnapshot document, String password) {
        Usuario usuario = new Usuario();
        usuario.setIzena(document.getString("Nombre"));
        usuario.setAbizena(document.getString("Apellido"));
        usuario.setEmail(document.getString("Email"));
        usuario.setPasahitza(password); // Pasar la contraseña ya validada
        usuario.setNivel(document.getString("nivel"));
        usuario.setEntrenatzailea(Boolean.TRUE.equals(document.getBoolean("Entrenador")));

        Timestamp fechaNacimientoTimestamp = document.getTimestamp("fecha de nacimiento");
        if (fechaNacimientoTimestamp != null) {
            usuario.setJaiotzeData(fechaNacimientoTimestamp.toDate());
        }

        return usuario;
    }

    private void cargarPreferencias() {
        // Cargar solo email y contraseña si "Remember me" está activado
        String savedEmail = prefs.getString("email", "");
        String savedPassword = prefs.getString("password", "");
        etErabiltzailea.setText(savedEmail);
        etPasahitza.setText(savedPassword);
        chkRememberMe.setChecked(prefs.getBoolean("rememberMe", false));
    }

    private void gestionarPreferencias(String email, String contrasena) {
        SharedPreferences.Editor editor = prefs.edit();
        // Guardar solo email y contraseña si "Remember me" está activado
        if (chkRememberMe.isChecked()) {
            editor.putString("email", email);
            editor.putString("password", contrasena);
            editor.putBoolean("rememberMe", true);
        } else {
            // Si no está activado, eliminar datos de "Remember me"
            editor.remove("email");
            editor.remove("password");
            editor.putBoolean("rememberMe", false);
        }
        editor.apply();
    }
}
