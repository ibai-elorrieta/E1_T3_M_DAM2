package com.example.erronkat3;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {

    private EditText etErabiltzailea, etPasahitza;
    private CheckBox chkRememberMe;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Inicializar Firebase Auth
        FirebaseApp.initializeApp(this);

        // Inicializar los elementos de la vista
        etErabiltzailea = findViewById(R.id.etErabiltzailea);
        etPasahitza = findViewById(R.id.etPasahitza);
        chkRememberMe = findViewById(R.id.chkRememberMe);
        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnErregistratu = findViewById(R.id.btnErregistratu);

        // Recuperar datos guardados (si es que hay)
        SharedPreferences prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        String savedUser = prefs.getString("username", "");
        String savedPassword = prefs.getString("password", "");
        etErabiltzailea.setText(savedUser);
        etPasahitza.setText(savedPassword);
        chkRememberMe.setChecked(!savedUser.isEmpty());

        // Acción del botón Login
        btnLogin.setOnClickListener(v -> {
            String erabiltzailea = etErabiltzailea.getText().toString();
            String pasahitza = etPasahitza.getText().toString();

            if (erabiltzailea.isEmpty() || pasahitza.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Bete erabiltzailea eta gakoa", Toast.LENGTH_SHORT).show();
            } else {
                // Lógica de autenticación con Firebase
                mAuth.signInWithEmailAndPassword(erabiltzailea, pasahitza)
                        .addOnCompleteListener(this, task -> {
                            if (task.isSuccessful()) {
                                // Inicio de sesión exitoso
                                Toast.makeText(LoginActivity.this, "Saioa hasi da", Toast.LENGTH_SHORT).show();
                                // Guardar usuario y contraseña si "Recordar Me" está marcado
                                if (chkRememberMe.isChecked()) {
                                    SharedPreferences.Editor editor = prefs.edit();
                                    editor.putString("username", erabiltzailea);
                                    editor.putString("password", pasahitza);
                                    editor.apply();
                                } else {
                                    // Limpiar si no está marcado
                                    SharedPreferences.Editor editor = prefs.edit();
                                    editor.clear();
                                    editor.apply();
                                }
                                // Redirigir a la pantalla principal
                                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                                startActivity(intent);
                                finish(); // Finaliza la actividad de login si no la necesitas más
                            } else {
                                // Si falla el inicio de sesión
                                Toast.makeText(LoginActivity.this, "Saioa hastean errorea", Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });

        // Acción del botón Erregistratu
        btnErregistratu.setOnClickListener(v -> {
            // Navegar a la pantalla de registro (RegistroActivity)
            Intent intent = new Intent(LoginActivity.this, Erregistroa.class);
            startActivity(intent);
        });
    }
}
