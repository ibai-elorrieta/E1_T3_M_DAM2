package com.example.erronkat3;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import androidx.appcompat.widget.SwitchCompat;
import android.widget.EditText;
import android.view.View;
import android.widget.AdapterView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.DocumentSnapshot;

public class Profila extends BaseActivity {

    private boolean isDarkTheme;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profila);

        SharedPreferences prefs = getSharedPreferences("Settings", MODE_PRIVATE);
        isDarkTheme = prefs.getBoolean("isDarkTheme", false);

        // Configuración del Switch para tema oscuro/claro
        SwitchCompat themeSwitch = findViewById(R.id.themeSwitch);
        themeSwitch.setChecked(isDarkTheme);

        themeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            isDarkTheme = isChecked;
            SharedPreferences.Editor editor = prefs.edit();
            editor.putBoolean("isDarkTheme", isDarkTheme);
            editor.apply();
            recreate();
        });

        // Configuración del Spinner para cambiar idioma
        Spinner languageSpinner = findViewById(R.id.languageSpinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.language_options, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        languageSpinner.setAdapter(adapter);

        String language = prefs.getString("language", "eu");
        languageSpinner.setSelection(language.equals("es") ? 1 : 0);

        languageSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedLanguage = position == 1 ? "es" : "eu";
                if (!language.equals(selectedLanguage)) {
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putString("language", selectedLanguage);
                    editor.apply();
                    recreate();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        // Botón de regreso a Entrenamendua
        Button btnItzuli = findViewById(R.id.btnItzuli);
        btnItzuli.setOnClickListener(v -> {
            Intent intent = new Intent(Profila.this, Entrenamendua.class);
            startActivity(intent);
            finish();
        });

        // Cargar los datos del usuario de Firebase
        FirebaseAuth auth = FirebaseAuth.getInstance();
        FirebaseUser user = auth.getCurrentUser();
        if (user != null) {
            String userId = user.getUid();
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            DocumentReference userRef = db.collection("Usuarios").document(userId);

            userRef.get().addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        // Recuperar los datos del documento de Firebase
                        String nombre = document.getString("Nombre");
                        String apellido = document.getString("Apellido");
                        String fechaNacimiento = document.getString("fecha de nacimiento");

                        // Referencias a los EditText en el layout
                        EditText etNombre = findViewById(R.id.etIzena);
                        EditText etApellido = findViewById(R.id.etAbizena);
                        EditText etFechaNacimiento = findViewById(R.id.etJaiotzeData);

                        // Mostrar los datos en los campos de texto
                        etNombre.setText(nombre);
                        etApellido.setText(apellido);
                        etFechaNacimiento.setText(fechaNacimiento);
                    } else {
                        Log.e("Profila", "El documento de usuario no existe.");
                    }
                } else {
                    Log.e("Profila", "Error al obtener los datos del usuario.", task.getException());
                }
            });
        } else {
            Log.e("Profila", "El usuario no está autenticado.");
        }
    }
}