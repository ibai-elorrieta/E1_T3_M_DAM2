package com.example.erronkat3;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.ArrayAdapter;

import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.SwitchCompat;
import android.view.View;
import android.widget.AdapterView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Locale;


public class Profila extends BaseActivity {

    private boolean isDarkTheme;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profila);

        // Obtener preferencias del tema
        SharedPreferences prefs = getSharedPreferences("Settings", MODE_PRIVATE);
        isDarkTheme = prefs.getBoolean("isDarkTheme", false);

        // Configuración del Switch para tema oscuro/claro
        SwitchCompat themeSwitch = findViewById(R.id.themeSwitch);
        themeSwitch.setChecked(isDarkTheme);

        // Dentro del listener del Switch
        themeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            SharedPreferences.Editor editor = prefs.edit();
            editor.putBoolean("isDarkTheme", isChecked);
            editor.apply();

            // Aplicar el cambio de tema
            AppCompatDelegate.setDefaultNightMode(isChecked ?
                    AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO);

            recreate(); // Opcional: Recargar la actividad
        });

        // Configuración del Spinner para cambiar idioma
        Spinner languageSpinner = findViewById(R.id.languageSpinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.language_options, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        languageSpinner.setAdapter(adapter);

        String language = prefs.getString("language", "eu");
        languageSpinner.setSelection(language.equals("es") ? 1 : 0);

        languageSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedLanguage = position == 1 ? "es" : "eu";
                if (!language.equals(selectedLanguage)) {
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putString("language", selectedLanguage);
                    editor.apply();
                    recreate(); // Recarga la actividad para aplicar el nuevo idioma
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        // Obtener el usuario actual desde la clase Usuario
        Usuario usuario = Usuario.getUsuarioActual();

        // Verificar si el usuario no es nulo
        if (usuario != null) {
            // Referencias a los TextView en el layout
            TextView etNombre = findViewById(R.id.etIzena);
            TextView etApellido = findViewById(R.id.etAbizena);
            TextView etFechaNacimiento = findViewById(R.id.etJaiotzeData);
            TextView etEmail = findViewById(R.id.etEmail); // Nuevo campo para email

            // Mostrar los datos en los campos de texto
            etNombre.setText(usuario.getIzena());
            etApellido.setText(usuario.getAbizena());

            if (usuario.getJaiotzeData() != null) {
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
                etFechaNacimiento.setText(dateFormat.format(usuario.getJaiotzeData()));
            } else {
                etFechaNacimiento.setText("Fecha no disponible");
            }

            if (usuario.getEmail() != null) {
                etEmail.setText(usuario.getEmail());
            } else {
                etEmail.setText("Email no disponible");
            }
        } else {
            Log.e("Profila", "No se ha encontrado un usuario válido.");
        }

        // Botón de regreso a Entrenamendua
        Button btnItzuli = findViewById(R.id.btnItzuli);
        btnItzuli.setOnClickListener(v -> {
            Intent intent = new Intent(Profila.this, Entrenamendua.class);
            startActivity(intent);
            finish();
        });
    }
}
