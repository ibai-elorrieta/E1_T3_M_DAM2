package com.example.erronkat3;

import com.google.firebase.Timestamp;

public class Usuario {
    private String apellido;
    private String email;
    private Boolean entrenador;
    private String nombre;
    private String contraseña;
    private Timestamp fechaDeNacimiento;
    private String nivel;


    // Constructor con parámetros
    public Usuario(String apellido, String nombre, String email, String contraseña, Timestamp fechaDeNacimiento, Boolean entrenador, String nivel) {
        this.apellido = apellido;
        this.email = email;
        this.entrenador = entrenador;
        this.nombre = nombre;
        this.contraseña = contraseña;
        this.fechaDeNacimiento = fechaDeNacimiento;
        this.nivel = nivel;
    }

    // Getters y setters para cada campo
    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Boolean getEntrenador() {
        return entrenador;
    }

    public void setEntrenador(Boolean entrenador) {
        this.entrenador = entrenador;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public Timestamp getFechaDeNacimiento() {
        return fechaDeNacimiento;
    }

    public void setFechaDeNacimiento(Timestamp fechaDeNacimiento) {
        this.fechaDeNacimiento = fechaDeNacimiento;
    }

    public String getNivel() {
        return nivel;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }
}
