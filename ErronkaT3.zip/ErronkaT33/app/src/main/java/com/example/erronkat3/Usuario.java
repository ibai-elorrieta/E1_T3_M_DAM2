package com.example.erronkat3;

import java.util.Date;

public class Usuario {
    private String izena;
    private String abizena;
    private String email;
    private String pasahitza;
    private Date jaiotzeData;
    private boolean entrenatzailea;
    private String nivel;

    public Usuario(String izena, String abizena, String email,String pasahitza, Date jaiotzeData, boolean entrenatzailea, String nivel) {
        this.izena = izena;
        this.abizena = abizena;
        this.email = email;
        this.pasahitza = pasahitza;
        this.jaiotzeData = jaiotzeData;
        this.entrenatzailea = entrenatzailea;
        this.nivel = nivel;
    }

    // Getters
    public String getIzena() {
        return izena;
    }

    public String getAbizena() {
        return abizena;
    }

    public String getEmail() {
        return email;
    }

    public String getPasahitza() {
        return pasahitza;
    }

    public Date getJaiotzeData() {
        return jaiotzeData;
    }

    public boolean isEntrenatzailea() {
        return entrenatzailea;
    }

    public String getNivel() {
        return nivel;
    }
}
