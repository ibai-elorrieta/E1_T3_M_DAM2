package com.example.erronkat3;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class EntrenamientoAdapter extends RecyclerView.Adapter<EntrenamientoAdapter.ViewHolder> {

    private List<Entrenamiento> entrenamientoList;

    public EntrenamientoAdapter(List<Entrenamiento> entrenamientoList) {
        this.entrenamientoList = entrenamientoList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_entrenamiento, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Entrenamiento entrenamiento = entrenamientoList.get(position);
        holder.nombreTextView.setText(entrenamiento.getNombre());
        holder.nivelTextView.setText(entrenamiento.getNivel());
    }

    @Override
    public int getItemCount() {
        return entrenamientoList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView nombreTextView, nivelTextView;

        public ViewHolder(View itemView) {
            super(itemView);
            nombreTextView = itemView.findViewById(R.id.tvNombreEntrenamiento);
            nivelTextView = itemView.findViewById(R.id.tvNivelEntrenamiento);
        }
    }
}