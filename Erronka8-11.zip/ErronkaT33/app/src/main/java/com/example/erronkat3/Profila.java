package com.example.erronkat3;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.Switch;
import android.widget.EditText;
import android.view.View;
import android.widget.AdapterView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.DocumentSnapshot;
import java.util.Locale;

public class Profila extends AppCompatActivity {

    private boolean isDarkTheme;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Recuperar tema actual de preferencias
        SharedPreferences prefs = getSharedPreferences("Settings", MODE_PRIVATE);
        isDarkTheme = prefs.getBoolean("isDarkTheme", false);
        setTheme(isDarkTheme ? R.style.Theme_ErronkaT3_Dark : R.style.Theme_ErronkaT3_Light);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profila);

        // Configuración del `Switch` para tema oscuro/claro
        @SuppressLint("UseSwitchCompatOrMaterialCode") Switch themeSwitch = findViewById(R.id.themeSwitch);
        themeSwitch.setChecked(isDarkTheme);

        themeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            isDarkTheme = isChecked;
            SharedPreferences.Editor editor = prefs.edit();
            editor.putBoolean("isDarkTheme", isDarkTheme);
            editor.apply();

            // Recargar actividad para aplicar el tema
            recreate();
        });

        // Configuración del `Spinner` para cambiar idioma
        Spinner languageSpinner = findViewById(R.id.languageSpinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.language_options, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        languageSpinner.setAdapter(adapter);

        // Cargar idioma guardado en preferencias
        String language = prefs.getString("language", "eu");
        languageSpinner.setSelection(language.equals("es") ? 1 : 0);

        languageSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedLanguage = position == 1 ? "es" : "eu"; // 0: Euskera, 1: Español
                if (!language.equals(selectedLanguage)) {
                    // Guardar idioma y reiniciar la actividad
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putString("language", selectedLanguage);
                    editor.apply();
                    setLocale(selectedLanguage);
                    recreate();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // No hacer nada
            }
        });

        // Botón de volver
        Button btnItzuli = findViewById(R.id.btnItzuli);
        btnItzuli.setOnClickListener(v -> finish());

        // Cargar los datos del usuario de Firebase
        FirebaseAuth auth = FirebaseAuth.getInstance();
        FirebaseUser user = auth.getCurrentUser();

        if (user != null) {
            String userId = user.getUid();  // Obtener el UID del usuario autenticado
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            DocumentReference userRef = db.collection("users").document(userId);

            // Obtener los datos del usuario desde Firestore
            userRef.get().addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        // Obtener los datos del documento de Firestore
                        String izena = document.getString("izena");
                        String abizena = document.getString("abizena");
                        String email = document.getString("email");
                        String jaiotzeData = document.getString("jaiotzeData");

                        // Llenar los EditText con los valores obtenidos
                        EditText etIzena = findViewById(R.id.etIzena);
                        EditText etAbizena = findViewById(R.id.etAbizena);
                        EditText etEmail = findViewById(R.id.etEmail);
                        EditText etJaiotzeData = findViewById(R.id.etJaiotzeData);

                        etIzena.setText(izena);
                        etAbizena.setText(abizena);
                        etEmail.setText(email);
                        etJaiotzeData.setText(jaiotzeData);
                    } else {
                        // Si no existe el documento
                        Log.e("Profila", "El documento de usuario no existe.");
                    }
                } else {
                    Log.e("Profila", "Error al obtener los datos del usuario.", task.getException());
                }
            });
        } else {
            // El usuario no está autenticado
            Log.e("Profila", "El usuario no está autenticado.");
        }
    }

    // Método para cambiar idioma
    private void setLocale(String langCode) {
        Locale locale = new Locale(langCode);
        Locale.setDefault(locale);
        android.content.res.Configuration config = getResources().getConfiguration();
        config.setLocale(locale);
        getResources().updateConfiguration(config, getResources().getDisplayMetrics());
    }
}
