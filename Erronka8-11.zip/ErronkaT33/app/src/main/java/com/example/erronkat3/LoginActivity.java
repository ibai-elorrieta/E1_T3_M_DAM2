package com.example.erronkat3;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {

    private EditText etErabiltzailea, etPasahitza;
    private CheckBox chkRememberMe;
    private FirebaseAuth mAuth;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Inicializar Firebase y Auth
        FirebaseApp.initializeApp(this);
        mAuth = FirebaseAuth.getInstance();

        // Inicializar los elementos de la vista
        etErabiltzailea = findViewById(R.id.etErabiltzailea);
        etPasahitza = findViewById(R.id.etPasahitza);
        chkRememberMe = findViewById(R.id.chkRememberMe);
        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnErregistratu = findViewById(R.id.btnErregistratu);

        // Inicializar preferencias compartidas
        prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        cargarPreferencias();

        // Acción del botón Login
        btnLogin.setOnClickListener(v -> {
            String erabiltzailea = etErabiltzailea.getText().toString().trim();
            String pasahitza = etPasahitza.getText().toString().trim();

            if (erabiltzailea.isEmpty() || pasahitza.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Bete erabiltzailea eta gakoa", Toast.LENGTH_SHORT).show();
            } else if (!Patterns.EMAIL_ADDRESS.matcher(erabiltzailea).matches()) {
                Toast.makeText(this, "Sartu baliozko posta elektronikoa", Toast.LENGTH_SHORT).show();
            } else {
                // Lógica de autenticación con Firebase
                mAuth.signInWithEmailAndPassword(erabiltzailea, pasahitza)
                        .addOnCompleteListener(this, task -> {
                            if (task.isSuccessful()) {
                                // Inicio de sesión exitoso
                                Toast.makeText(LoginActivity.this, "Saioa hasi da", Toast.LENGTH_SHORT).show();
                                gestionarPreferencias(erabiltzailea, pasahitza);
                                // Redirigir a la pantalla principal
                                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                                startActivity(intent);
                                finish(); // Finaliza la actividad de login si no la necesitas más
                            } else {
                                // Si falla el inicio de sesión, muestra el mensaje de error específico
                                String errorMsg = task.getException() != null ? task.getException().getMessage() : "Errore ezezaguna";
                                Toast.makeText(LoginActivity.this, "Saioa hastean errorea: " + errorMsg, Toast.LENGTH_LONG).show();
                            }
                        });
            }
        });

        // Acción del botón Erregistratu
        btnErregistratu.setOnClickListener(v -> {
            // Navegar a la pantalla de registro (ErregistroActivity)
            Intent intent = new Intent(LoginActivity.this, Erregistroa.class);
            startActivity(intent);
        });
    }

    private void cargarPreferencias() {
        // Recuperar el último usuario y contraseña guardados si Remember Me está activado
        String savedUser = prefs.getString("username", "");
        String savedPassword = prefs.getString("password", "");
        etErabiltzailea.setText(savedUser);
        etPasahitza.setText(savedPassword);
        chkRememberMe.setChecked(prefs.getBoolean("rememberMe", false));
    }

    private void gestionarPreferencias(String erabiltzailea, String pasahitza) {
        SharedPreferences.Editor editor = prefs.edit();
        if (chkRememberMe.isChecked()) {
            editor.putString("username", erabiltzailea);
            editor.putString("password", pasahitza);
            editor.putBoolean("rememberMe", true);
        } else {
            // Limpiar si no está marcado
            editor.clear();
        }
        editor.apply();
    }
}
